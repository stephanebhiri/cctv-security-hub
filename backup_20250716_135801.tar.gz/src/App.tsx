import React, { useState } from 'react';
import { CCTVService, CCTVResponse } from './services/CCTVService';
import VideoPlayer from './components/VideoPlayer';
import VideoGrid from './components/VideoGrid';
import ItemsSection from './components/ItemsSection';
import './App.css';

const App: React.FC = () => {
  const [selectedCamera, setSelectedCamera] = useState<number>(1);
  const [selectedDateTime, setSelectedDateTime] = useState<string>('');
  const [currentVideo, setCurrentVideo] = useState<string | null>(null);
  const [videoData, setVideoData] = useState<CCTVResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [videoSectionVisible, setVideoSectionVisible] = useState(false);
  const [currentItemName, setCurrentItemName] = useState<string>('');
  const [loadingMessage, setLoadingMessage] = useState<string>('');

  const cctvService = new CCTVService();

  const handleSearch = async () => {
    if (!selectedDateTime) {
      setError('Please select a date and time');
      return;
    }

    setLoading(true);
    setError(null);
    setCurrentVideo(null); // Vider le player pendant le chargement

    try {
      const timestamp = Math.floor(new Date(selectedDateTime).getTime() / 1000);
      
      console.time('api-response-time');
      console.log('🚀 Starting API call for timestamp:', timestamp);
      
      const response = await cctvService.getVideos(timestamp, selectedCamera);
      
      console.timeEnd('api-response-time');
      console.log('🎬 CCTV Response:', { 
        videosCount: Object.keys(response.videos).length,
        closestIndex: response.closestIndex,
        cameraId: response.cameraId 
      });
      
      setVideoData(response);
      
      // Set the closest video as the current video
      const closestVideoUrl = response.videos[response.closestIndex.toString()];
      console.log('🎯 Closest video URL:', closestVideoUrl);
      
      if (!closestVideoUrl) {
        console.error('❌ No video URL found for closest index:', response.closestIndex);
        setError('No video found for selected time');
        return;
      }
      
      console.time('total-time-to-video-ready');
      setCurrentVideo(closestVideoUrl);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch videos');
      setVideoData(null);
      setCurrentVideo(null);
    } finally {
      setLoading(false);
    }
  };

  const handleVideoSelect = (videoUrl: string) => {
    setCurrentVideo(videoUrl);
  };

  const handleTestAPI = async () => {
    setLoading(true);
    setError(null);

    try {
      // Test with known timestamp from instructions
      const testTimestamp = 1752567000; // 2025-07-15T08:10:00
      const response = await cctvService.getVideos(testTimestamp, selectedCamera);
      
      setVideoData(response);
      const closestVideoUrl = response.videos[response.closestIndex.toString()];
      setCurrentVideo(closestVideoUrl);
      
      // Update the datetime picker to show the test time
      const testDate = new Date(testTimestamp * 1000);
      const dateTimeString = testDate.toISOString().slice(0, 16);
      setSelectedDateTime(dateTimeString);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'API test failed');
    } finally {
      setLoading(false);
    }
  };

  const handleItemClick = async (timestamp: number, designation: string, groupId: number) => {
    console.log(`🎬 Launching CCTV for item: ${designation} at timestamp: ${timestamp}`);
    
    setLoading(true);
    setError(null);
    setCurrentVideo(null); // Vider le player pendant le chargement
    setCurrentItemName(designation);
    setVideoSectionVisible(true);

    try {
      // Update datetime picker to show item time
      const itemDate = new Date(timestamp * 1000);
      setSelectedDateTime(itemDate.toISOString().slice(0, 16));
      
      // Default to camera 1 - could be made configurable
      const cameraId = 1;
      setSelectedCamera(cameraId);
      
      // Fetch CCTV videos for this timestamp
      const response = await cctvService.getVideos(timestamp, cameraId);
      setVideoData(response);
      
      // Set the closest video as current
      const closestVideoUrl = response.videos[response.closestIndex.toString()];
      setCurrentVideo(closestVideoUrl);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load CCTV footage');
    } finally {
      setLoading(false);
    }
  };

  const handleHealthCheck = async () => {
    setLoading(true);
    setError(null);

    try {
      const health = await cctvService.checkHealth();
      if (health.status === 'healthy') {
        alert(`✅ API is healthy! Timestamp: ${new Date(health.timestamp * 1000).toLocaleString()}`);
      } else {
        setError('API health check failed');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Health check failed');
    } finally {
      setLoading(false);
    }
  };

  const closeVideoPlayer = () => {
    setVideoSectionVisible(false);
  };

  const handleEraseCache = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir vider le cache vidéo ?')) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const result = await cctvService.eraseCache();
      if (result.success) {
        window.alert(`✅ Cache vidé avec succès !\n${result.filesDeleted} fichiers supprimés\n${result.sizeFreed}MB libérés`);
      } else {
        setError('Échec du vidage du cache');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Échec du vidage du cache');
    } finally {
      setLoading(false);
    }
  };

  // Edge case test handlers
  const handleTestSlowResponse = async () => {
    setLoading(true);
    setError(null);
    setLoadingMessage('Testing slow response (6+ seconds)...');
    setVideoSectionVisible(true);
    setCurrentItemName('Slow Response Test');

    try {
      const response = await cctvService.testSlowResponse(6000);
      setVideoData(response);
      
      const closestVideoUrl = response.videos[response.closestIndex.toString()];
      setCurrentVideo(closestVideoUrl);
      
      console.log('✅ Slow response test completed');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Slow response test failed');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  const handleTest404Response = async () => {
    setLoading(true);
    setError(null);
    setLoadingMessage('Testing 404 video handling...');
    setVideoSectionVisible(true);
    setCurrentItemName('404 Video Test');

    try {
      const response = await cctvService.test404Response();
      setVideoData(response);
      
      const closestVideoUrl = response.videos[response.closestIndex.toString()];
      setCurrentVideo(closestVideoUrl);
      
      console.log('✅ 404 response test completed');
    } catch (err) {
      setError(err instanceof Error ? err.message : '404 response test failed');
    } finally {
      setLoading(false);
      setLoadingMessage('');
    }
  };

  const handleTestRapidClicks = async () => {
    console.log('🚀 Testing rapid consecutive clicks...');
    setVideoSectionVisible(true);
    setCurrentItemName('Rapid Click Test');
    
    // Simulate rapid clicks on different items
    const testItems = [
      { timestamp: 1752567000, designation: 'Item 1', groupId: 1 },
      { timestamp: 1752567060, designation: 'Item 2', groupId: 2 },
      { timestamp: 1752567120, designation: 'Item 3', groupId: 3 },
      { timestamp: 1752567180, designation: 'Item 4', groupId: 4 },
      { timestamp: 1752567240, designation: 'Item 5', groupId: 5 }
    ];
    
    // Fire rapid requests
    for (let i = 0; i < testItems.length; i++) {
      const item = testItems[i];
      console.log(`📍 Rapid click ${i + 1}: ${item.designation}`);
      
      // Don't await - fire them rapidly
      handleItemClick(item.timestamp, item.designation, item.groupId);
      
      // Small delay between clicks
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    console.log('✅ Rapid click test initiated - check console for request cancellations');
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>CCTV Video Viewer</h1>
        <p>Select camera and time to view CCTV footage</p>
      </header>

      <main className="App-main">
        {error && (
          <div className="error-message">
            <p>Error: {error}</p>
          </div>
        )}

        {/* Edge Case Test Controls */}
        <div className="edge-case-tests" style={{
          padding: '20px',
          backgroundColor: '#f8f9fa',
          marginBottom: '20px',
          borderRadius: '8px',
          border: '1px solid #dee2e6'
        }}>
          <h3>🧪 Edge Case Tests</h3>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button 
              onClick={handleTestSlowResponse}
              disabled={loading}
              style={{
                padding: '8px 16px',
                backgroundColor: '#ffc107',
                color: '#000',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer'
              }}
            >
              🐌 Test Slow Response (6s)
            </button>
            <button 
              onClick={handleTest404Response}
              disabled={loading}
              style={{
                padding: '8px 16px',
                backgroundColor: '#dc3545',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer'
              }}
            >
              🚫 Test 404 Videos
            </button>
            <button 
              onClick={handleTestRapidClicks}
              disabled={loading}
              style={{
                padding: '8px 16px',
                backgroundColor: '#17a2b8',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer'
              }}
            >
              🚀 Test Rapid Clicks
            </button>
            <button 
              onClick={handleHealthCheck}
              disabled={loading}
              style={{
                padding: '8px 16px',
                backgroundColor: '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer'
              }}
            >
              ❤️ Health Check
            </button>
            <button 
              onClick={handleEraseCache}
              disabled={loading}
              style={{
                padding: '8px 16px',
                backgroundColor: '#dc3545',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer'
              }}
            >
              🗑️ Erase Cache
            </button>
          </div>
          {loading && loadingMessage && (
            <div style={{
              marginTop: '10px',
              padding: '10px',
              backgroundColor: '#e3f2fd',
              borderRadius: '4px',
              color: '#1976d2'
            }}>
              {loadingMessage}
            </div>
          )}
        </div>

        {/* Items Table - Main Content */}
        <ItemsSection 
          onItemClick={handleItemClick}
          onHealthCheck={handleHealthCheck}
        />

        {/* CCTV Modal - Elegant overlay player */}
        {videoSectionVisible && (
          <div className="modal-overlay" onClick={closeVideoPlayer}>
            <div className="modal-container" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2>📹 {currentItemName}</h2>
                <button className="close-btn" onClick={closeVideoPlayer}>
                  ✕
                </button>
              </div>
              
              <div className="modal-content">
                <div className="main-video">
                  <VideoPlayer 
                    videoUrl={currentVideo}
                    onError={() => setError('Failed to load video')}
                    isSearching={loading}
                  />
                </div>
                
                <div className="video-controls">
                  <div className="control-row">
                    <select 
                      value={selectedCamera} 
                      onChange={(e) => setSelectedCamera(parseInt(e.target.value))}
                      className="control-select"
                    >
                      {[1, 2, 3, 4, 5, 6].map(num => (
                        <option key={num} value={num}>📷 Camera {num}</option>
                      ))}
                    </select>
                    
                    <input
                      type="datetime-local"
                      value={selectedDateTime}
                      onChange={(e) => setSelectedDateTime(e.target.value)}
                      className="control-datetime"
                    />
                    
                    <button onClick={handleSearch} disabled={loading} className="search-btn">
                      {loading ? '⏳' : '🔍'} Search
                    </button>
                  </div>
                </div>
                
                {videoData && (
                  <div className="compact-video-grid">
                    <h4>📼 Related Videos</h4>
                    <VideoGrid
                      videos={videoData.videos}
                      timestamps={videoData.timestamps}
                      onVideoSelect={handleVideoSelect}
                      closestIndex={videoData.closestIndex}
                    />
                  </div>
                )}
                
                {videoData && (
                  <div className="video-meta">
                    📊 Camera {videoData.cameraId} • {Object.keys(videoData.videos).length} videos • {videoData.offsetSeconds}s offset
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;