import React, { useState, useCallback, useMemo } from 'react';
import { useItems } from '../hooks/useItems';
import { useAutoRefresh } from '../hooks/useAutoRefresh';
import ItemsTable from './ItemsTable';

interface ItemsSectionProps {
  onItemClick: (timestamp: number, designation: string, groupId: number) => void;
  onHealthCheck: () => void;
}

// Extract styles to prevent object recreation on every render
const styles = {
  headerContainer: {
    display: 'flex' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    marginBottom: '15px'
  },
  buttonContainer: {
    display: 'flex' as const,
    gap: '10px',
    alignItems: 'center' as const
  },
  baseButton: {
    color: 'white',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '4px',
    cursor: 'pointer'
  },
  refreshButtonOn: {
    background: '#28a745'
  },
  refreshButtonOff: {
    background: '#dc3545'
  },
  healthButton: {
    background: '#3498db'
  },
  errorMessage: {
    background: '#e74c3c',
    color: 'white',
    padding: '15px',
    margin: '20px 0',
    borderRadius: '4px'
  },
  loading: {
    textAlign: 'center' as const,
    padding: '20px',
    color: '#7f8c8d'
  },
  infoBar: {
    background: '#ecf0f1',
    padding: '15px',
    margin: '20px 0',
    borderRadius: '4px',
    display: 'flex' as const,
    gap: '20px',
    fontSize: '14px'
  }
} as const;

const ItemsSection: React.FC<ItemsSectionProps> = React.memo(({ onItemClick, onHealthCheck }) => {
  const { items, loading, error, refetch } = useItems();
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState(true);

  // Memoized callbacks to prevent unnecessary re-renders
  const silentRefresh = useCallback(() => {
    refetch(true);
  }, [refetch]);

  const toggleAutoRefresh = useCallback(() => {
    setAutoRefreshEnabled(prev => !prev);
  }, []);

  useAutoRefresh(silentRefresh, 5000, autoRefreshEnabled);

  // Memoized computed values
  const refreshButtonStyle = useMemo(() => ({
    ...styles.baseButton,
    ...(autoRefreshEnabled ? styles.refreshButtonOn : styles.refreshButtonOff)
  }), [autoRefreshEnabled]);

  const healthButtonStyle = useMemo(() => ({
    ...styles.baseButton,
    ...styles.healthButton
  }), []);

  const currentTime = useMemo(() => new Date().toLocaleTimeString(), [items.length]);

  return (
    <div className="items-section">
      <div style={styles.headerContainer}>
        <div>
          <h2>Items Inventory - Real-time</h2>
          <p>Click on any item to view CCTV footage from that timestamp</p>
        </div>
        <div style={styles.buttonContainer}>
          <button 
            onClick={toggleAutoRefresh}
            style={refreshButtonStyle}
          >
            {autoRefreshEnabled ? '🔄 Auto-refresh ON' : '⏸️ Auto-refresh OFF'}
          </button>
          <button 
            onClick={onHealthCheck}
            style={healthButtonStyle}
          >
            Health Check
          </button>
        </div>
      </div>

      {error && (
        <div style={styles.errorMessage}>
          <p>Error: {error}</p>
        </div>
      )}

      {loading && (
        <div style={styles.loading}>
          Loading items...
        </div>
      )}

      <ItemsTable items={items} onItemClick={onItemClick} />

      <div style={styles.infoBar}>
        <span>Total Items: {items.length}</span>
        <span>Last Updated: {currentTime}</span>
        <span>Auto-refresh: {autoRefreshEnabled ? 'Every 5 seconds' : 'Disabled'}</span>
        <span>Click any item to view CCTV footage from that timestamp</span>
      </div>
    </div>
  );
});

// Add display name for debugging
ItemsSection.displayName = 'ItemsSection';

export default ItemsSection;