import React, { useState } from 'react';

interface VideoPlayerProps {
  videoUrl: string | null;
  onError?: () => void;
  isSearching?: boolean;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ videoUrl, onError, isSearching }) => {
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const handleError = (event: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    console.error('Video playback error:', event);
    setHasError(true);
    setIsLoading(false);
    onError?.();
  };

  const handleLoadStart = () => {
    setIsLoading(true);
    setHasError(false);
    console.time('video-load-time');
    console.log('📼 Video loading started:', videoUrl);
  };

  const handleCanPlay = () => {
    setIsLoading(false);
    setHasError(false);
    console.timeEnd('video-load-time');
    console.timeEnd('total-time-to-video-ready');
    console.log('✅ Video ready to play:', videoUrl);
  };

  if (!videoUrl) {
    console.log('❌ VideoPlayer: No video URL provided:', videoUrl);
    return (
      <div className="video-placeholder">
        {isSearching ? (
          <div style={{ textAlign: 'center' }}>
            <div style={{
              width: '50px',
              height: '50px',
              margin: '0 auto 20px',
              border: '3px solid #667eea',
              borderRadius: '50%',
              borderTopColor: 'transparent',
              animation: 'spin 1s linear infinite'
            }} />
            <p>🔍 Recherche des vidéos...</p>
            <p style={{fontSize: '14px', color: '#888', marginTop: '10px'}}>Chargement en cours</p>
          </div>
        ) : (
          <>
            <p>Aucune vidéo sélectionnée</p>
            <p style={{fontSize: '14px', color: '#888', marginTop: '10px'}}>Cliquez sur un élément ou utilisez la recherche</p>
          </>
        )}
      </div>
    );
  }
  
  console.log('🎥 VideoPlayer: Rendering video:', videoUrl);

  if (hasError) {
    return (
      <div className="video-error">
        <p>❌ Video could not be loaded (404 or corrupted)</p>
        <p>URL: {videoUrl}</p>
        <button 
          onClick={() => {
            setHasError(false);
            setIsLoading(true);
          }}
          style={{
            padding: '8px 16px',
            marginTop: '10px',
            backgroundColor: '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="video-player">
      {isLoading && (
        <div className="video-loading" style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          zIndex: 10,
          backgroundColor: 'rgba(0,0,0,0.8)',
          color: 'white',
          padding: '10px 20px',
          borderRadius: '4px'
        }}>
          📥 Téléchargement en cours...
        </div>
      )}
      <video
        controls
        autoPlay
        width="100%"
        height="400"
        onError={handleError}
        onLoadStart={handleLoadStart}
        onCanPlay={handleCanPlay}
        preload="metadata"
        key={videoUrl}
      >
        <source src={videoUrl} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </div>
  );
};

export default VideoPlayer;